CREATE VIEW student_course_view AS
  SELECT test_student.name AS "Name",
    test_course.name_course AS "Name course"
   FROM ((student_course
     JOIN test_course ON ((student_course.id_course = test_course.id)))
     JOIN test_student ON ((student_course.id_student = test_student.id)));

